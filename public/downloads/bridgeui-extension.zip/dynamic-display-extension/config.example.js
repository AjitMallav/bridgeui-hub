// Copy this file to config.js and fill in your keys. Do NOT commit config.js.
export const STATSIG_CLIENT_KEY = ""; // e.g., client-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
export const GEMINI_API_KEY = ""; // optional; leave blank to disable DESCRIBE_IMAGE
export const GEMINI_MODEL = "models/gemini-2.0-flash-exp"; // optional override
