BridgeUI extension demo zip placeholder
